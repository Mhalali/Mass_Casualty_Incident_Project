Welcome to the Mass_Casualty_Incident_Project Wiki!

Welcome to the Mass_Casualty_Incident_Project wiki! This space is dedicated to providing detailed documentation, setup guides, and development progress for the MCI bot project.

# MCI Wiki Homepage

Welcome to the MCI Bot Project Wiki! Use the links below to navigate through the different sections:

- [Issue Tracking](./Issue-Tracking)
- [Planned Features](./Planned-Features)
- [Setup Instructions](./Setup-Instructions)
- [Technical Documentation](./Technical-Documentation)
- [Project Development & History](./ProjectDH)


Whether you're a developer, tester, or collaborator, this wiki serves as a comprehensive guide for navigating and contributing to the project.

For more information or inquiries, please contact: Mohamed Alali
Email: [Mhalali@dubaihealth.ae](mailto:Mhalali@dubaihealth.ae)