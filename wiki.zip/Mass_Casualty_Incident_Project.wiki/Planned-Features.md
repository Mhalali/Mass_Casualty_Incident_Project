# Feature Roadmap

This page outlines the planned features and enhancements for the MCI Bot.

## Current Version: `v0.1-alpha`

### Features in `v0.1-alpha`:
- Text-based interactive scenarios for triage, treatment, and transport decisions.
- Real-time analysis of user performance with post-scenario feedback.

### Planned Features:

- **Voice Integration (v0.2-beta)**: Reintroduce Speech-to-Text (STT) and Text-to-Speech (TTS) using Azure Speech Services.
- **Biometric Integration**: Integrating health apps and sensors (e.g., heart rate) to enhance scenario realism.
- **Expanded Game Features**: More complex scenarios, additional roles, and further control commands for facilitators.
- **Cloud Deployment Options**: Further refine cloud hosting on Azure and Raspberry Pi setups.

### Upcoming Releases:

- **`v0.2-beta`**:
  - Voice-based interaction with STT/TTS.
  - Additional bot commands for greater control.

Stay tuned for future updates!
