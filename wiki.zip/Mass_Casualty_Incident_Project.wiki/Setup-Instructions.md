This guide will walk you through setting up the MCI Bot locally or on a Raspberry Pi.

## Prerequisites

- **Python 3.x**: Ensure Python 3.x is installed.
- **Git**: Ensure Git is installed for version control.
- **OpenAI API Key**: Obtain an OpenAI API key for GPT integration.
- **Discord Developer Account**: Set up a Discord bot and obtain the token.

## Installation Steps

1. **Clone the Repository:**
    ```bash
    git clone https://github.com/YourGitHubAccount/Mass_Casualty_Incident_Project.git
    cd Mass_Casualty_Incident_Project
    ```

2. **Set Up Environment Variables**:
    Create a `.env` file in the root directory with the following content:
    ```bash
    DISCORD_TOKEN=your-discord-bot-token
    OPENAI_API_KEY=your-openai-api-key
    ```

3. **Install Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

4. **Run the Bot**:
    ```bash
    python MCIBot.py
    ```

You're now ready to start the bot locally or on Raspberry Pi!
