This page documents the key milestones, tools, and technologies used throughout the development of the Mass Casualty Incident (MCI) Bot project.

# Phase 1: NFC Integration with Discord
- **Tools Used**: IFTTT, NFC Tools, Tasker, Discord API
- **Description**: In the early stages of development, we integrated NFC tags to trigger in-game events through Discord via IFTTT. This allowed physical NFC tags to represent victims, vehicles, and zones in the game.
- **Milestone**: Successfully linked over 100 NFC tags to game actions, such as assigning roles or handling victims' data.

## Sample Code for NFC IFTTT Event Trigger:
`python`
`import requests`
`IFTTT_KEY = 'https://maker.ifttt.com/trigger/game_trigger/with/key/YOUR_KEY_HERE'`

## Example function to trigger IFTTT event
`def trigger_ifttt_event(event_name, value1, value2):`
    `url = f"{IFTTT_KEY}?value1={value1}&value2={value2}"`
    `requests.post(url)`

# Phase 2: Text-Based NLP and OpenAI Integration

* Tools Used: Python, OpenAI GPT, Discord API
* Description: After experimenting with NFC, we shifted focus to text-based Natural Language Processing (NLP) using OpenAI’s GPT model to generate real-time responses during gameplay.
* Milestone: Successfully integrated GPT into the bot for dynamic interactions with players.

## Sample Code for GPT Integration:

`import openai`
`openai.api_key = 'your-openai-api-key'`

`def get_nlp_response(prompt):`
    `response = openai.Completion.create(`
        `engine="text-davinci-003",`
        `prompt=prompt,`
        `max_tokens=150`
    `)`
    `return response.choices[0].text.strip()`

# Phase 3: Voice Interaction (Ongoing)

* Tools Used: Microsoft Azure Speech-to-Text (STT) and Text-to-Speech (TTS), Python
* Description: We are currently exploring voice-based interaction for the MCI game using Azure STT and TTS services.
* Milestone: Ongoing integration and testing for voice-based commands and scenario updates in the game.

## Voice Integration Sample (Azure STT/TTS):

`import azure.cognitiveservices.speech as speechsdk`

`speech_key = "your-azure-speech-key"`
`service_region = "your-region"`

`speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)`
`speech_recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config)`

`def recognize_speech():`
    `result = speech_recognizer.recognize_once()`
    `return result.text`

# Terminated Phases
1. Google Cloud TTS/STT

* Reason: Due to regional restrictions on Google Cloud services, the integration had to be abandoned, and we transitioned to Azure Speech Services.
* Outcome: Migrated to Microsoft Azure for Speech-to-Text (STT) and Text-to-Speech (TTS).

2. Azure STT on Raspberry Pi

* Reason: Performance limitations with Raspberry Pi hardware resulted in poor compatibility with Azure Speech Services.
* Outcome: Shifted to other hardware options for voice interaction development.
