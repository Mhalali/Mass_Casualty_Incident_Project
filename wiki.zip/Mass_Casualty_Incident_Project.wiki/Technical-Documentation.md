This page provides technical details and developer notes on the MCI Bot.

## Environment Variables

The bot uses environment variables to manage sensitive information like API keys. Ensure you have the following set up in a `.env` file:

DISCORD_TOKEN=your-discord-bot-token
OPENAI_API_KEY=your-openai-api-key

## Bot Commands

    !reset: Resets the simulation and stops the game, allowing players to restart when ready.
    !setupadmin: Creates necessary roles and channels for the bot on Discord.

## **Hosting**
**Raspberry Pi Setup**

    Preferred Hosting Solution: Raspberry Pi 5 or similar.
    Use a process manager like pm2 or systemd to ensure the bot stays online.

**Azure App Service (Optional)**

    Hosting the bot on Azure App Service is still an option.
    Set environment variables through the Azure portal for smooth operation.

**Future Integrations**

    STT/TTS: Planned re-integration of Azure Speech Services for voice commands.
    Biometric Data: Investigating the use of wearable devices for more immersive simulations.

For further questions, refer to the main repository or contact the project owner.